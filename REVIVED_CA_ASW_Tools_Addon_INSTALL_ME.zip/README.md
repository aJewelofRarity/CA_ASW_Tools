# CA_ASW_Tools
Tools made to work with ArcSystemWorks models exported from Umodel as GLTF
Guide can be Found here: https://docs.google.com/document/d/1m_h7p1WYypsvx2bpqFwvOS_aT1Vr_-jp5GQZK_X2dNA/edit?usp=sharing
